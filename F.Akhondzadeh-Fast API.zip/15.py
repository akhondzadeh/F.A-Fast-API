from fastapi import FastAPI
from pydantic import BaseModel, Field, field_validator

FACULTY_LIST = ["فنی_و_مهندسی", "علوم_پایه", "علوم انسانی", "دامپزشکی", "اقتصاد کشاورزی", "منابع طبیعی"]
MARITAL_STATUS_LIST = ["مجرد", "متاهل"]

ENGINEERING_FIELDS = {
    "برق": ["قدرت", "کنترل", "مخابرات", "الکترونیک", "ماشین‌های الکتریکی"],
    "عمران": ["سازه", "آب", "محیط زیست", "حمل و نقل", "نقشه برداری"],
    "مکانیک": ["طراحی جامدات", "حرارت و سیالات", "ساخت و تولید", "بیومکانیک", "خودرو"],
    "کامپیوتر": ["نرم افزار", "سخت افزار", "هوش مصنوعی", "شبکه های کامپیوتری", "امنیت"],
}

provinces2 = {
 "آذربایجان شرقی": ["تبریز", "آذرشهر", "اهر", "بناب", "بوکان", "جلفا", "سراب", "شبستر", "عجب شیر", "مراغه", "مرند", "ملکان", "میانه", "هشترود", "هریس"],
    "آذربایجان غربی": ["ارومیه", "بوکان", "پیرانشهر", "تکاب", "چالدران", "خوی", "سلماس", "سردشت", "شاهین دژ", "ماکو", "مهاباد", "میاندوآب", "نقده", "وشت", "سردشت"],
    "اردبیل": ["اردبیل", "خلخال", "کوثر", "مشگین شهر", "نیر", "نمین"],
    "اصفهان": ["اصفهان", "آران و بیدگل", "اردستان", "برخوار و میمه", "خمینی شهر", "سمیرم", "شاهین شهر و میمه", "شهرضا", "فلاورجان", "کاشان", "لنجان", "نجف آباد", "نطنز"],
    "البرز": ["کرج", "اشتهارد", "ساوجبلاغ", "نظرآباد"],
    "ایلام": ["ایلام", "آبدانان", "ایوان", "بدره", "دره شهر", "دهلران", "چرداول", "ملکشاهی"],
    "بوشهر": ["بوشهر", "دشتستان", "دیلم", "گناوه", "جم", "کنگان", "تنگستان", "دشتی"],
    "تهران": ["تهران", "اسلامشهر", "بهارستان", "پاکدشت", "دماوند", "رباط کریم", "ری", "شمیرانات", "فیروزکوه", "قرچک", "ورامین"],
    "چهارمحال و بختیاری": ["شهرکرد", "اردل", "بروجن", "سامان", "کیار", "لردگان", "فارسان", "کوهرنگ"],
    "خراسان جنوبی": ["بیرجند", "بشرویه", "خوسف", "درمیان", "سربیشه", "سرایان", "نهبندان", "قاینات"],
    "خراسان رضوی": ["مشهد", "بینالود", "چناران", "درگز", "رشتخوار", "سبزوار", "سرخس", "فریمان", "قوچان", "کلات", "گناباد", "مشهد", "نیشابور", "فیروزه"],
    "خراسان شمالی": ["بجنورد", "اسفراین", "گرمه", "جاجرم", "شیروان", "فاروج", "مانه و سملقان"],
    "خوزستان": ["اهواز", "آبادان", "اندیمشک", "ایذه", "باغملک", "بهبهان", "خرمشهر", "دزفول", "دشت آزادگان", "رامهرمز", "شادگان", "شوش", "شوشتر", "گتوند", "هویزه", "ماهشهر"],
    "زنجان": ["زنجان", "ابهر", "ایجرود", "خدابنده", "خرمدره", "ماهنشان", "طارم"],
    "سمنان": ["سمنان", "دامغان", "شاهرود", "گرمسار", "مهدی شهر", "سرخه"],
    "سیستان و بلوچستان": ["زاهدان", "زابل", "زهک", "خاش", "سراوان", "سیب و سوران", "چابهار", "ایرانشهر", "مهرستان", "نیکشهر"],
    "فارس": ["شیراز", "اقلید", "آباده", "بوانات", "پاسارگاد", "جهرم", "خرم بید", "داراب", "رستم", "زرقان", "سپیدان", "سروستان", "فسا", "فیروزآباد", "قیر و کارزین", "کازرون", "لامرد", "لارستان", "ممسنی", "مهر", "نی ریز"],
    "قزوین": ["قزوین", "آبیک", "البرز", "بوئین زهرا", "تاکستان"],
    "قم": ["قم", "جعفرآباد"],
    "کردستان": ["سنندج", "بانه", "بیجار", "دیواندره", "سقز", "قروه", "کامیاران", "مریوان"],
    "کرمان": ["کرمان", "ارزوئیه", "بافت", "بردسیر", "بم", "جیرفت", "راور", "رفسنجان", "رودبار جنوب", "زرند", "سیرجان", "شهر بابک", "عنبرآباد", "فهرج", "قلعه گنج", "کوهبنان", "مانوجان"],
    "کرمانشاه": ["کرمانشاه", "اسلام آبادغرب", "ثلاث باباجانی", "دالاهو", "سرپل ذهاب", "قصرشیرین", "گیلانغرب", "هجیر", "پاوه"],
    "کهگیلویه و بویراحمد": ["یاسوج", "باشت", "بهبهان", "چرام", "دنا", "گچساران", "لنده", "مارگون"],
    "گلستان": ["گرگان", "آزادشهر", "علی آبادکتول", "بندرگز", "رامیان", "کردکوی", "گنبد کاووس", "مینودشت"],
    "گیلان": ["رشت", "آستارا", "املش", "انزلی", "آستانه اشرفیه", "بندر انزلی", "تالش", "رضوانشهر", "رودسر", "رشت", " سیاهکل", "شفت", "صومعه سرا", "فومن", "لاهیجان", "لنگرود", "ماسوله", "ماسال"],
    "لرستان": ["خرم‌آباد", "ازنا", "الیگودرز", "بروجرد", "پلدختر", "چگنی", "دورود", "دلفان", "سلسله", "کوهدشت", "رومشکان"],
    "مازندران": ["ساری", "آمل", "بابل", "بابلسر", "بهشهر", "تنکابن", "جویبار", "سوادکوه", " قائم شهر", "محمودآباد", "نکا", "نور", "نوشهر", "چالوس", "رامسر", "سلمانشهر"],
    "مرکزی": ["اراک", "آشتیان", "تفرش", "خمین", "دلیجان", "زرندیه", "ساوه", "شازند", "کمیجان", "محلات"],
    "هرمزگان": ["بندرعباس", "ابوموسی", "بستک", " بندر لنگه", "جاسک", "حاجی آباد", "خمیر", "رودان", "میناب", "قشم", "کلاهی", "پارسیان"],
    "همدان": ["همدان", "اسدآباد", "بهار", "تویسرکان", "رزن", "فامنین", "کبودراهنگ", "ملایر", "نهاوند"],
    "یزد": ["یزد", "ابرکوه", "اردکان", "بافق", " بهاباد", "تفت", "خاتم", "مهریز", "میبد", "اشکذر"],
}



provinces = {
    "آذربایجان-شرقی": "تبریز",
    "آذربایجان-غربی": "ارومیه",
    "اردبیل": "اردبیل",
    "اصفهان": "اصفهان",
    "البرز": "کرج",
    "ایلام": "ایلام",
    "بوشهر": "بوشهر",
    "تهران": "تهران",
    "چهارمحال-و-بختیاری": "شهرکرد",
    "خراسان-جنوبی": "بیرجند",
    "خراسان-رضوی": "مشهد",
    "خراسان-شمالی": "بجنورد",
    "خوزستان": "اهواز",
    "زنجان": "زنجان",
    "سمنان": "سمنان",
    "سیستان-و-بلوچستان": "زاهدان",
    "فارس": "شیراز",
    "قزوین": "قزوین",
    "قم": "قم",
    "کردستان": "سنندج",
    "کرمان": "کرمان",
    "کرمانشاه": "کرمانشاه",
    "کهگیلویه-و-بویراحمد": "یاسوج",
    "گلستان": "گرگان",
    "گیلان": "رشت",
    "لرستان": "خرم‌آباد",
    "مازندران": "ساری",
    "مرکزی": "اراک",
    "هرمزگان": "بندرعباس",
    "همدان": "همدان",
    "یزد": "یزد",
}

app = FastAPI()

class StudentInfo(BaseModel):
    student_number: str = Field(..., description="The student ID number")
    name: str = Field(..., description="The student's name (فارسی characters and spaces only)")
    birthdate: str = Field(..., description="The student's birthdate in YYYY.MM.DD format")
    serial_number: str = Field(..., description="The student's national ID serial number")
    province_code: str = Field(..., description="The student's province of birth code")
    city: str = Field(..., description="The student's city of birth")
    address: str = Field(..., description="The student's address (max 100 characters)")
    postal_code: str = Field(..., description="The student's postal code (10 digits)")
    phone_number: str = Field(..., description="The student's mobile phone number (starting with 09 and 11 digits)")
    landline_number: str = Field(..., description="The student's landline phone number (starting with 0 and at least 10 digits)")
    faculty: str = Field(..., description="The student's faculty")
    field: str = Field(..., description="The student's engineering field")
    major: str = Field(..., description="The student's major within the engineering field")
    marital_status: str = Field(..., description="The student's marital status")
    national_id: str = Field(..., description="The student's national ID number (10 digits)")

    @field_validator('student_number')
    def validate_student_number(cls, value):
        if len(value) != 11:
            raise ValueError("شماره دانشجویی باید ۱۱ رقم باشد.")
        if not value.startswith("402"):
            raise ValueError("قسمت سال نادرست است.")
        if value[3:9] != "114150":
            raise ValueError("قسمت ثابت نادرست است.")
        index = int(value[9:])
        if index < 1 or index > 99:
            raise ValueError("قسمت اندیس نادرست است.")
        return value

    @field_validator('name')
    def validate_name(cls, value):
        if len(value) > 10:
            raise ValueError("نام باید حداکثر 10 حرف باشد.")
        for char in value:
            if not char.isalpha() and char != " ":
                raise ValueError("نام فقط باید شامل حروف فارسی و فاصله باشد.")
        if any(char.isdigit() or char in "!@#$%^&*()" for char in value):
            raise ValueError("نام نباید شامل عدد یا علائم خاص باشد.")
        return value

    @field_validator('birthdate')
    def validate_birthdate(cls, value):
        import datetime
        try:
            datetime.datetime.strptime(value, "%Y.%m.%d")
        except ValueError:
            raise ValueError("تاریخ تولد باید به فرمت YYYY.MM.DD باشد.")

        year, month, day = map(int, value.split("."))

        if year < 1300 or year > 1500:
            raise ValueError("سال تولد باید بین 1300 تا 1500 باشد.")

        if month < 1 or month > 12:
            raise ValueError("ماه تولد باید بین 1 تا 12 باشد.")

        if day < 1 or day > 31:
            raise ValueError("روز تولد باید بین 1 تا 31 باشد.")

        if month == 2 and day == 29 and not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
            raise ValueError("این تاریخ در سال غیر کبیسه February 29 نیست.")

        return value

    @field_validator('serial_number')
    def validate_serial_number(cls, value):
        import re
        if len(value) != 9:
            raise ValueError("سریال شناسنامه باید 9 رقم باشد.")

        if not value[:6].isdigit():
            raise ValueError("بخش اول سریال باید عددی باشد.")

        if not re.match(r"^[آ-ی]+$", value[6:7]):
            raise ValueError("بخش دوم سریال باید فقط شامل حروف فارسی باشد.")

        if not value[7:].isdigit():
            raise ValueError("بخش سوم سریال باید عددی باشد.")

        return value

    @field_validator('province_code')
    def validate_province_code(cls, value):
        value = value.replace("-", "")  # Remove hyphens
        if value not in provinces.keys():
            raise ValueError("استان وارد شده صحیح نیست.")
        return value

    @field_validator('city')
    def validate_city(cls, value):
        found = False
        for province, cities in provinces2.items():
            if value in cities:
                found = True
                break
        if not found:
            raise ValueError("شهرستان مورد نظر یافت نشد.")
        return value

    @field_validator('address')
    def validate_address(cls, value):
        if len(value) > 100:
            raise ValueError("آدرس باید حداکثر 100 کاراکتر باشد.")
        return value

    @field_validator('postal_code')
    def validate_postal_code(cls, value):
        if not value.isdigit() or len(value) != 10:
            raise ValueError("کد پستی باید یک عدد 10 رقمی باشد.")
        return value

    @field_validator('phone_number')
    def validate_phone_number(cls, value):
        if not value.startswith("09") or not value.isdigit() or len(value) != 11:
            raise ValueError("شماره تلفن همراه باید با 09 شروع شود و یک عدد 11 رقمی باشد.")
        return value

    @field_validator('landline_number')
    def validate_landline_number(cls, value):
        if not value.startswith("0") or not value.isdigit() or len(value) < 10:
            raise ValueError("شماره تلفن ثابت باید با 0 شروع شود و یک عدد 10 رقمی یا بیشتر باشد.")
        return value

    @field_validator('faculty')
    def validate_faculty(cls, value):
        if value not in FACULTY_LIST:
            raise ValueError("دانشکده وارد شده صحیح نیست.")
        return value

    @field_validator('field')
    def validate_field(cls, value):
        if value not in ENGINEERING_FIELDS:
            raise ValueError("حوزه مهندسی وارد شده صحیح نیست.")
        return value

    # @field_validator('major')
    # def validate_major(cls, value, values):
    #     field = values.get('field')
    #     if field not in ENGINEERING_FIELDS:
    #         raise ValueError("ابتدا باید حوزه مهندسی را وارد کنید.")
    #     if value not in ENGINEERING_FIELDS[field]:
    #         raise ValueError("رشته تحصیلی وارد شده صحیح نیست.")
    #     return value
    @field_validator('major')
    def validate_major(cls, value, values):
        valid_majors = ["برق", "عمران", "مکانیک", "صنایع", "کامپیوتر","اپتیک"]
        if value not in valid_majors:
            raise ValueError("رشته تحصیلی وارد شده صحیح نیست.")
        return value

    @field_validator('marital_status')
    def validate_marital_status(cls, value):
        if value not in MARITAL_STATUS_LIST:
            raise ValueError("وضعیت تاهل وارد شده صحیح نیست.")
        return value

    @field_validator('national_id')
    def validate_national_id(cls, value):
        if not value.isdigit() or len(value) != 10:
            raise ValueError("کد ملی باید یک عدد 10 رقمی باشد.")
        return value

@app.post("/student-info")
async def check_student_info(student_info: StudentInfo):
    return student_info