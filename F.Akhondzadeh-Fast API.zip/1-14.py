from fastapi import FastAPI, Body, HTTPException
from pydantic import BaseModel
from datetime import datetime
import re






FACULTY_LIST = ["فنی_و_مهندسی", "علوم_پایه", "علوم انسانی", "دامپزشکی", "اقتصاد کشاورزی", "منابع طبیعی"]
MARITAL_STATUS_LIST = ["مجرد", "متاهل"]

ENGINEERING_FIELDS = {
    "برق": ["قدرت", "کنترل", "مخابرات", "الکترونیک", "ماشین‌های الکتریکی"],
    "عمران": ["سازه", "آب", "محیط زیست", "حمل و نقل", "نقشه برداری"],
    "مکانیک": ["طراحی جامدات", "حرارت و سیالات", "ساخت و تولید", "بیومکانیک", "خودرو"],
    "کامپیوتر": ["نرم افزار", "سخت افزار", "هوش مصنوعی", "شبکه های کامپیوتری", "امنیت"],
}

provinces = {
    "آذربایجان-شرقی": "تبریز",
    "آذربایجان-غربی": "ارومیه",
    "اردبیل": "اردبیل",
    "اصفهان": "اصفهان",
    "البرز": "کرج",
    "ایلام": "ایلام",
    "بوشهر": "بوشهر",
    "تهران": "تهران",
    "چهارمحال-و-بختیاری": "شهرکرد",
    "خراسان-جنوبی": "بیرجند",
    "خراسان-رضوی": "مشهد",
    "خراسان-شمالی": "بجنورد",
    "خوزستان": "اهواز",
    "زنجان": "زنجان",
    "سمنان": "سمنان",
    "سیستان-و-بلوچستان": "زاهدان",
    "فارس": "شیراز",
    "قزوین": "قزوین",
    "قم": "قم",
    "کردستان": "سنندج",
    "کرمان": "کرمان",
    "کرمانشاه": "کرمانشاه",
    "کهگیلویه-و-بویراحمد": "یاسوج",
    "گلستان": "گرگان",
    "گیلان": "رشت",
    "لرستان": "خرم‌آباد",
    "مازندران": "ساری",
    "مرکزی": "اراک",
    "هرمزگان": "بندرعباس",
    "همدان": "همدان",
    "یزد": "یزد",
}

# لیست استان ها و شهرستان های ایران
provinces2 = {
 "آذربایجان شرقی": ["تبریز", "آذرشهر", "اهر", "بناب", "بوکان", "جلفا", "سراب", "شبستر", "عجب شیر", "مراغه", "مرند", "ملکان", "میانه", "هشترود", "هریس"],
    "آذربایجان غربی": ["ارومیه", "بوکان", "پیرانشهر", "تکاب", "چالدران", "خوی", "سلماس", "سردشت", "شاهین دژ", "ماکو", "مهاباد", "میاندوآب", "نقده", "وشت", "سردشت"],
    "اردبیل": ["اردبیل", "خلخال", "کوثر", "مشگین شهر", "نیر", "نمین"],
    "اصفهان": ["اصفهان", "آران و بیدگل", "اردستان", "برخوار و میمه", "خمینی شهر", "سمیرم", "شاهین شهر و میمه", "شهرضا", "فلاورجان", "کاشان", "لنجان", "نجف آباد", "نطنز"],
    "البرز": ["کرج", "اشتهارد", "ساوجبلاغ", "نظرآباد"],
    "ایلام": ["ایلام", "آبدانان", "ایوان", "بدره", "دره شهر", "دهلران", "چرداول", "ملکشاهی"],
    "بوشهر": ["بوشهر", "دشتستان", "دیلم", "گناوه", "جم", "کنگان", "تنگستان", "دشتی"],
    "تهران": ["تهران", "اسلامشهر", "بهارستان", "پاکدشت", "دماوند", "رباط کریم", "ری", "شمیرانات", "فیروزکوه", "قرچک", "ورامین"],
    "چهارمحال و بختیاری": ["شهرکرد", "اردل", "بروجن", "سامان", "کیار", "لردگان", "فارسان", "کوهرنگ"],
    "خراسان جنوبی": ["بیرجند", "بشرویه", "خوسف", "درمیان", "سربیشه", "سرایان", "نهبندان", "قاینات"],
    "خراسان رضوی": ["مشهد", "بینالود", "چناران", "درگز", "رشتخوار", "سبزوار", "سرخس", "فریمان", "قوچان", "کلات", "گناباد", "مشهد", "نیشابور", "فیروزه"],
    "خراسان شمالی": ["بجنورد", "اسفراین", "گرمه", "جاجرم", "شیروان", "فاروج", "مانه و سملقان"],
    "خوزستان": ["اهواز", "آبادان", "اندیمشک", "ایذه", "باغملک", "بهبهان", "خرمشهر", "دزفول", "دشت آزادگان", "رامهرمز", "شادگان", "شوش", "شوشتر", "گتوند", "هویزه", "ماهشهر"],
    "زنجان": ["زنجان", "ابهر", "ایجرود", "خدابنده", "خرمدره", "ماهنشان", "طارم"],
    "سمنان": ["سمنان", "دامغان", "شاهرود", "گرمسار", "مهدی شهر", "سرخه"],
    "سیستان و بلوچستان": ["زاهدان", "زابل", "زهک", "خاش", "سراوان", "سیب و سوران", "چابهار", "ایرانشهر", "مهرستان", "نیکشهر"],
    "فارس": ["شیراز", "اقلید", "آباده", "بوانات", "پاسارگاد", "جهرم", "خرم بید", "داراب", "رستم", "زرقان", "سپیدان", "سروستان", "فسا", "فیروزآباد", "قیر و کارزین", "کازرون", "لامرد", "لارستان", "ممسنی", "مهر", "نی ریز"],
    "قزوین": ["قزوین", "آبیک", "البرز", "بوئین زهرا", "تاکستان"],
    "قم": ["قم", "جعفرآباد"],
    "کردستان": ["سنندج", "بانه", "بیجار", "دیواندره", "سقز", "قروه", "کامیاران", "مریوان"],
    "کرمان": ["کرمان", "ارزوئیه", "بافت", "بردسیر", "بم", "جیرفت", "راور", "رفسنجان", "رودبار جنوب", "زرند", "سیرجان", "شهر بابک", "عنبرآباد", "فهرج", "قلعه گنج", "کوهبنان", "مانوجان"],
    "کرمانشاه": ["کرمانشاه", "اسلام آبادغرب", "ثلاث باباجانی", "دالاهو", "سرپل ذهاب", "قصرشیرین", "گیلانغرب", "هجیر", "پاوه"],
    "کهگیلویه و بویراحمد": ["یاسوج", "باشت", "بهبهان", "چرام", "دنا", "گچساران", "لنده", "مارگون"],
    "گلستان": ["گرگان", "آزادشهر", "علی آبادکتول", "بندرگز", "رامیان", "کردکوی", "گنبد کاووس", "مینودشت"],
    "گیلان": ["رشت", "آستارا", "املش", "انزلی", "آستانه اشرفیه", "بندر انزلی", "تالش", "رضوانشهر", "رودسر", "رشت", " سیاهکل", "شفت", "صومعه سرا", "فومن", "لاهیجان", "لنگرود", "ماسوله", "ماسال"],
    "لرستان": ["خرم‌آباد", "ازنا", "الیگودرز", "بروجرد", "پلدختر", "چگنی", "دورود", "دلفان", "سلسله", "کوهدشت", "رومشکان"],
    "مازندران": ["ساری", "آمل", "بابل", "بابلسر", "بهشهر", "تنکابن", "جویبار", "سوادکوه", " قائم شهر", "محمودآباد", "نکا", "نور", "نوشهر", "چالوس", "رامسر", "سلمانشهر"],
    "مرکزی": ["اراک", "آشتیان", "تفرش", "خمین", "دلیجان", "زرندیه", "ساوه", "شازند", "کمیجان", "محلات"],
    "هرمزگان": ["بندرعباس", "ابوموسی", "بستک", " بندر لنگه", "جاسک", "حاجی آباد", "خمیر", "رودان", "میناب", "قشم", "کلاهی", "پارسیان"],
    "همدان": ["همدان", "اسدآباد", "بهار", "تویسرکان", "رزن", "فامنین", "کبودراهنگ", "ملایر", "نهاوند"],
    "یزد": ["یزد", "ابرکوه", "اردکان", "بافق", " بهاباد", "تفت", "خاتم", "مهریز", "میبد", "اشکذر"],
}









#1-A
app = FastAPI()
@app.get("/student/{student_number}")
async def get_student_info(student_number: str):

    # بررسی طول شماره دانشجویی
    if len(student_number) != 11:
        return {"message": "شماره دانشجویی باید ۱۱ رقم باشد."}

    # بررسی پیشوند
    if not student_number.startswith("402"):
        return {"message": "قسمت سال نادرست است."}

    # بررسی بخش ثابت
    if student_number[3:9] != "114150":
        return {"message": "قسمت ثابت نادرست است."}
        #return {"message": student_number[3:9]}

    # بررسی اندیس
    index = int(student_number[9:])
    if index < 1 or index > 99:
        return {"message": "قسمت اندیس نادرست است."}

    return {"message": "شماره دانشجویی وارد شده درست است.", "student_number": student_number}
#1-B
# http://127.0.0.1:8000/student?student_number=40211416001

@app.get("/student")
async def get_student_info(student_number: str):


    # بررسی طول شماره دانشجویی
    if len(student_number) != 11:
        return {"message": "شماره دانشجویی باید ۱۱ رقم باشد."}

    # بررسی پیشوند
    if not student_number.startswith("402"):
        return {"message": "قسمت سال نادرست است."}

    # بررسی بخش ثابت
    if student_number[3:9] != "114150":
        return {"message": "قسمت ثابت نادرست است."}

    # بررسی اندیس
    index = int(student_number[9:])
    if index < 1 or index > 99:
        return {"message": "قسمت اندیس نادرست است."}

    return {"message": "شماره دانشجویی وارد شده درست است.", "student_number": student_number}


#1-C

class StudentNumber(BaseModel):
    student_number: str

@app.post("/student-info")
async def check_student_info(student_number: StudentNumber = Body(...)):


    # بررسی طول شماره دانشجویی
    if len(student_number.student_number) != 11:
        return {"message": "شماره دانشجویی باید ۱۱ رقم باشد."}

    # بررسی پیشوند
    if not student_number.student_number.startswith("402"):
        return {"message": "قسمت سال نادرست است."}

    # بررسی بخش ثابت
    if student_number.student_number[3:9] != "114150":
        return {"message": "قسمت ثابت نادرست است."}

    # بررسی اندیس
    index = int(student_number.student_number[9:])
    if index < 1 or index > 99:
        return {"message": "قسمت اندیس نادرست است."}


    return {"message": "شماره دانشجویی وارد شده درست است.", "student_number": student_number.student_number}

#2

@app.get("/name/{name}")
async def check_name(name: str):

    # بررسی طول نام
    if len(name) > 10:
        return {"message": "نام باید حداکثر 10 حرف باشد."}

    # بررسی کاراکترهای نام
    for char in name:
        if not char.isalpha() and char != " ":
            return {"message": "نام فقط باید شامل حروف فارسی و فاصله باشد."}

    # بررسی وجود عدد یا علائم خاص
    if any(char.isdigit() or char in "!@#$%^&*()" for char in name):
        return {"message": "نام نباید شامل عدد یا علائم خاص باشد."}

    return {"message": "نام وارد شده صحیح است.", "name": name}

#3

@app.get("/birthdate/{birthdate}")
async def check_birthdate(birthdate: str):

    # بررسی قالب تاریخ
    try:
        datetime.strptime(birthdate, "%Y.%m.%d")
    except ValueError:
        return {"message": "تاریخ تولد باید به فرمت YYYY.MM.DD باشد."}

    # Extract year, month, day
    year, month, day = map(int, birthdate.split("."))

    # بررسی سال
    if year < 1300 or year > 1500:
        return {"message": "سال تولد باید بین 1300 تا 1500 باشد."}

    # بررسی ماه
    if month < 1 or month > 12:
        return {"message": "ماه تولد باید بین 1 تا 12 باشد."}

    # بررسی روز
    if day < 1 or day > 31:
        return {"message": "روز تولد باید بین 1 تا 31 باشد."}

    # Basic check for leap year (more advanced libraries can be used)
    if month == 2 and day == 29 and not (year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)):
        return {"message": "این تاریخ در سال غیر کبیسه February 29 نیست."}

    return {"message": "تاریخ تولد وارد شده صحیح است.", "birthdate": birthdate}
#4

@app.get("/serial-number/{serial_number}")
async def check_serial_number(serial_number: str):


    # بررسی طول سریال
    if len(serial_number) != 9:
        return {"message": "سریال شناسنامه باید 9 رقم باشد."}

    # بررسی بخش اول
    if not serial_number[:6].isdigit():
        return {"message": "بخش اول سریال باید عددی باشد."}

    # بررسی بخش دوم
    if not re.match(r"^[آ-ی]+$", serial_number[6:7]):
        return {"message": "بخش دوم سریال باید فقط شامل حروف فارسی باشد."}

    # بررسی بخش سوم
    if not serial_number[7:].isdigit():
        return {"message": "بخش سوم سریال باید عددی باشد."}

    return {"message": "سریال شناسنامه وارد شده صحیح است.", "serial_number": serial_number}

#5


@app.get("/province/{province_code}")
async def check_province(province_code: str):

    province_code = province_code.replace("-", "")  # Replace hyphens with empty string

    if province_code not in provinces.keys():
        return {"message": "استان وارد شده صحیح نیست."}

    return {"message": "استان محل تولد وارد شده صحیح است."}

#6


@app.get("/validate-birthplace/{city}")
async def validate_birthplace(city: str):

    if not city:
        raise HTTPException(status_code=400, detail="نام شهرستان را وارد کنید")

    for province, cities in provinces2.items():
        if city in cities:
            return {"status": "یافت شد", "استان": province}

    raise HTTPException(status_code=404, detail="شهرستان مورد نظر یافت نشد")

#7


@app.get("/address/{address}")
async def check_address(address: str):

    if len(address) > 100:
        return {"message": "آدرس باید حداکثر 100 کاراکتر باشد."}

    return {"message": "آدرس وارد شده صحیح است."}
#8
@app.get("/postal-code/{postal_code}")
async def check_postal_code(postal_code: str):

    try:
        int(postal_code)
        if len(postal_code) != 10:
            raise ValueError
    except ValueError:
        return {"message": "کد پستی باید یک عدد 10 رقمی باشد."}

    return {"message": "کد پستی وارد شده صحیح است."}


#9
@app.get("/phone-number/{phone_number}")
async def check_phone_number(phone_number: str):


    if not phone_number.startswith("09"):
        return {"message": "شماره تلفن همراه باید با 09 شروع شود."}

    try:
        int(phone_number)
        if len(phone_number) != 11:
            raise ValueError
    except ValueError:
        return {"message": "شماره تلفن همراه باید یک عدد 11 رقمی باشد."}

    return {"message": "شماره تلفن همراه وارد شده صحیح است."}


#10
@app.get("/landline-number/{landline_number}")
async def check_landline_number(landline_number: str):

    if not landline_number.startswith("0"):
        return {"message": "شماره تلفن ثابت باید با 0 شروع شود."}

    try:
        int(landline_number)
        if len(landline_number) < 10:
            raise ValueError
    except ValueError:
        return {"message": "شماره تلفن ثابت باید یک عدد 10 رقمی یا بیشتر باشد."}

    return {"message": "شماره تلفن ثابت وارد شده صحیح است."}


# 11


@app.get("/faculty/{faculty}")
async def check_faculty(faculty: str):

    if faculty not in FACULTY_LIST:
        return {"message": "دانشکده وارد شده صحیح نیست."}

    return {"message": "دانشکده وارد شده صحیح است."}





#12
@app.get("/major/{field}/{major}")
async def check_major(field: str, major: str):

    if field not in ENGINEERING_FIELDS:
        return {"message": "حوزه مهندسی وارد شده صحیح نیست."}

    if major not in ENGINEERING_FIELDS[field]:
        return {"message": "رشته تحصیلی وارد شده صحیح نیست."}

    return {"message": "رشته تحصیلی وارد شده صحیح است."}


#13
@app.get("/marital-status/{marital_status}")
async def check_marital_status(marital_status: str):

    if marital_status not in MARITAL_STATUS_LIST:
        return {"message": "وضعیت تاهل وارد شده صحیح نیست."}

    return {"message": "وضعیت تاهل وارد شده صحیح است."}

#14
@app.get("/national-id/{national_id}")
async def check_national_id(national_id: str):

    if len(national_id) != 10:
        return {"message": "کد ملی باید 10 رقمی باشد."}


    return {"message": "کد ملی وارد شده صحیح است."}





